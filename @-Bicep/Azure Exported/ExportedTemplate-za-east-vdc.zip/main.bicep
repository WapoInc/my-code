param virtualNetworkGateways_ZA_East_vDC_VPN_GW_name string = 'ZA-East-vDC-VPN-GW'
param publicIPAddresses_ZA_East_vDC_VPN_GW_Pub_IP_externalid string = '/subscriptions/0cfd0d2a-2b38-4c93-ba14-cf79185bc683/resourceGroups/za-east-vdc/providers/Microsoft.Network/publicIPAddresses/ZA-East-vDC-VPN-GW-Pub-IP'
param virtualNetworks_ZA_East_vDC_vnet_externalid string = '/subscriptions/0cfd0d2a-2b38-4c93-ba14-cf79185bc683/resourceGroups/za-east-vdc/providers/Microsoft.Network/virtualNetworks/ZA-East-vDC-vnet'

resource virtualNetworkGateways_ZA_East_vDC_VPN_GW_name_resource 'Microsoft.Network/virtualNetworkGateways@2024-05-01' = {
  name: virtualNetworkGateways_ZA_East_vDC_VPN_GW_name
  location: 'southafricanorth'
  properties: {
    enablePrivateIpAddress: false
    ipConfigurations: [
      {
        name: 'default'
        id: '${virtualNetworkGateways_ZA_East_vDC_VPN_GW_name_resource.id}/ipConfigurations/default'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          publicIPAddress: {
            id: publicIPAddresses_ZA_East_vDC_VPN_GW_Pub_IP_externalid
          }
          subnet: {
            id: '${virtualNetworks_ZA_East_vDC_vnet_externalid}/subnets/GatewaySubnet'
          }
        }
      }
    ]
    natRules: []
    virtualNetworkGatewayPolicyGroups: []
    enableBgpRouteTranslationForNat: false
    disableIPSecReplayProtection: false
    sku: {
      name: 'VpnGw1'
      tier: 'VpnGw1'
    }
    gatewayType: 'Vpn'
    vpnType: 'RouteBased'
    enableBgp: true
    activeActive: false
    bgpSettings: {
      asn: 65515
      bgpPeeringAddress: '10.20.0.254'
      peerWeight: 0
      bgpPeeringAddresses: [
        {
          ipconfigurationId: '${virtualNetworkGateways_ZA_East_vDC_VPN_GW_name_resource.id}/ipConfigurations/default'
          customBgpIpAddresses: []
        }
      ]
    }
    vpnGatewayGeneration: 'Generation1'
    allowRemoteVnetTraffic: false
    allowVirtualWanTraffic: false
  }
}
