#!/usr/bin/env bash
# 05-tenant-preflight.sh — run BEFORE choosing between subscription transfer
# and rebuild, when source and target are in DIFFERENT Entra tenants.
#
# Finds every resource whose behaviour depends on tenant identity. These are the
# ones that break, and the CMK ones are the ones that can break UNRECOVERABLY.
#
# Read-only. Usage: ./05-tenant-preflight.sh <source-subscription-id>

set -euo pipefail

SRC_SUB="${1:?usage: 05-tenant-preflight.sh <source-sub-id>}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/inventory/_tenant-preflight"
mkdir -p "$OUT"

az account set --subscription "$SRC_SUB"
SRC_TENANT=$(az account show --query tenantId -o tsv)
echo "==> source sub $SRC_SUB in tenant $SRC_TENANT"

az extension add --name resource-graph --only-show-errors 2>/dev/null || true

# ---------------------------------------------------------------- 1. CMK RISK
# Highest priority. A key vault holding customer-managed keys for storage/SQL
# encryption-at-rest can produce an UNRECOVERABLE state during a tenant
# transfer. If anything shows up here, do not transfer without handling it.
echo "--> [1/6] customer-managed key dependencies (CRITICAL)"
az graph query -q "
  resources
  | where properties.encryption.keySource =~ 'Microsoft.Keyvault'
     or isnotempty(properties.encryptionSettingsCollection)
     or isnotempty(properties.encryption.keyVaultProperties)
  | project name, type, resourceGroup, encryption=properties.encryption
" --subscriptions "$SRC_SUB" -o json > "$OUT/01-cmk-dependencies.json" 2>/dev/null || echo '[]' > "$OUT/01-cmk-dependencies.json"

CMK=$(jq '.data | length' "$OUT/01-cmk-dependencies.json" 2>/dev/null || echo 0)
if [[ "$CMK" -gt 0 ]]; then
  echo "    !! $CMK resource(s) use customer-managed keys."
  echo "    !! Tenant transfer risks UNRECOVERABLE data loss. Rebuild instead,"
  echo "    !! or disable CMK / repoint to a vault outside the moving scope first."
fi

# ---------------------------------------------------- 2. identity-bearing resources
# Every managed identity below gets a NEW principalId in the target tenant.
# Anything granting permission TO these must be rewritten.
echo "--> [2/6] resources with managed identities"
az graph query -q "
  resources
  | where isnotempty(identity)
  | project name, type, resourceGroup, identityType=identity.type,
            principalId=identity.principalId,
            userAssigned=identity.userAssignedIdentities
" --subscriptions "$SRC_SUB" -o json > "$OUT/02-managed-identities.json" 2>/dev/null || echo '[]' > "$OUT/02-managed-identities.json"

# ------------------------------------------------------- 3. key vault tenant binding
echo "--> [3/6] key vaults and access policies"
az keyvault list --query "[].{name:name, rg:resourceGroup}" -o tsv | while read -r KV RG; do
  az keyvault show -n "$KV" \
    --query "{name:name, tenantId:properties.tenantId, rbacAuth:properties.enableRbacAuthorization, policies:properties.accessPolicies}" \
    -o json > "$OUT/03-keyvault-$KV.json" 2>/dev/null || true
done

# ------------------------------------------------------ 4. SQL Entra admins
echo "--> [4/6] SQL servers with Entra authentication"
az sql server list --query "[].{name:name, rg:resourceGroup}" -o tsv 2>/dev/null | while read -r SRV RG; do
  az sql server ad-admin list -g "$RG" -s "$SRV" -o json \
    > "$OUT/04-sql-adadmin-$SRV.json" 2>/dev/null || true
done

# --------------------------------------- 5. RBAC — PERMANENTLY DELETED on transfer
# On a tenant transfer these are destroyed and unrecoverable. This file is your
# only record. Back it up somewhere outside the subscription.
echo "--> [5/6] full RBAC snapshot (irreplaceable — store off-subscription)"
az role assignment list --all --include-inherited \
  --query "[].{principal:principalName, principalId:principalId, type:principalType, role:roleDefinitionName, scope:scope}" \
  -o json > "$OUT/05-rbac-FULL-BACKUP.json"

az role definition list --custom-role-only true -o json \
  > "$OUT/05-custom-roles-FULL-BACKUP.json"

# ---------------------------------------------- 6. federated credentials / app regs
echo "--> [6/6] user-assigned identities with federated credentials"
az identity list --query "[].{name:name, rg:resourceGroup, id:id}" -o tsv | while read -r NAME RG ID; do
  FC=$(az identity federated-credential list --identity-name "$NAME" -g "$RG" -o json 2>/dev/null || echo '[]')
  [[ $(echo "$FC" | jq 'length') -gt 0 ]] && echo "$FC" > "$OUT/06-fedcred-$NAME.json"
done

# ------------------------------------------------------------------- summary
echo
echo "================ CROSS-TENANT PRE-FLIGHT ================"
echo "CMK dependencies (unrecoverable risk): $CMK"
echo "Managed identities (all get new IDs):  $(jq '.data | length' "$OUT/02-managed-identities.json" 2>/dev/null || echo '?')"
echo "Key vaults (tenantId must change):     $(ls "$OUT"/03-keyvault-*.json 2>/dev/null | wc -l)"
echo "SQL Entra admins to re-point:          $(ls "$OUT"/04-sql-adadmin-*.json 2>/dev/null | wc -l)"
echo "RBAC assignments (DELETED on transfer):$(jq 'length' "$OUT/05-rbac-FULL-BACKUP.json")"
echo "Custom roles to recreate:              $(jq 'length' "$OUT/05-custom-roles-FULL-BACKUP.json")"
echo "Federated credentials to re-register:  $(ls "$OUT"/06-fedcred-*.json 2>/dev/null | wc -l)"
echo "========================================================="
echo
echo "Decision guide:"
echo "  CMK count > 0        -> do NOT transfer tenant; rebuild, or remove CMK first"
echo "  Many app regs / OIDC -> rebuild (client IDs change either way)"
echo "  Large stateful data  -> transfer may still win despite the RBAC wipe"
echo
echo "Copy $OUT/05-rbac-FULL-BACKUP.json somewhere OUTSIDE this subscription now."
