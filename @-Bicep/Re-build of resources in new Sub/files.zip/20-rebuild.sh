#!/usr/bin/env bash
# 20-rebuild.sh — bootstrap the TARGET subscription and deploy the hand-cleaned
# templates from ./templates/.
#
# Run 10-capture.sh first. Then hand-write ./templates/<rg>/main.bicep using the
# export as reference — do NOT deploy the raw export.
#
# Usage: ./20-rebuild.sh <target-subscription-id> <resource-group> <location> [--apply]

set -euo pipefail

TGT_SUB="${1:?usage: 20-rebuild.sh <target-sub-id> <rg> <location> [--apply]}"
RG="${2:?resource group name required}"
LOC="${3:?location required}"
APPLY="${4:-}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TPL="$ROOT/templates/$RG/main.bicep"
PARAMS="$ROOT/templates/$RG/main.bicepparam"
INV="$ROOT/inventory"

[[ -f "$TPL" ]] || { echo "no template at $TPL — write it first"; exit 1; }

az account set --subscription "$TGT_SUB"
echo "==> target: $(az account show --query name -o tsv)"

# ---------------------------------------------------- 1. register providers
# A new subscription has almost nothing registered. Registration is async and
# can take several minutes, so do it before anything else.
if [[ -f "$INV/_subscription/registered-providers.json" ]]; then
  echo "--> registering providers"
  jq -r '.[]' "$INV/_subscription/registered-providers.json" | while read -r NS; do
    STATE=$(az provider show -n "$NS" --query registrationState -o tsv 2>/dev/null || echo "NotFound")
    if [[ "$STATE" != "Registered" ]]; then
      echo "    registering $NS"
      az provider register -n "$NS" --no-wait 2>/dev/null || true
    fi
  done
fi

# ---------------------------------------------------- 2. custom role defs
if [[ -s "$INV/_subscription/custom-role-definitions.json" ]]; then
  echo "--> recreating custom roles (rewriting assignableScopes to target sub)"
  jq -c '.[]' "$INV/_subscription/custom-role-definitions.json" | while read -r ROLE; do
    NAME=$(echo "$ROLE" | jq -r '.roleName')
    az role definition show --name "$NAME" &>/dev/null && { echo "    exists: $NAME"; continue; }
    echo "$ROLE" | jq --arg sub "/subscriptions/$TGT_SUB" \
      '{Name: .roleName, Description: .description,
        Actions: .permissions[0].actions,
        NotActions: .permissions[0].notActions,
        DataActions: .permissions[0].dataActions,
        NotDataActions: .permissions[0].notDataActions,
        AssignableScopes: [$sub]}' > /tmp/role.json
    az role definition create --role-definition /tmp/role.json || echo "    !! failed: $NAME"
  done
fi

# ---------------------------------------------------- 3. resource group
az group create -n "$RG" -l "$LOC" -o none
echo "--> resource group $RG ready"

# ---------------------------------------------------- 4. what-if, ALWAYS
PARAM_ARG=()
[[ -f "$PARAMS" ]] && PARAM_ARG=(--parameters "$PARAMS")

echo "--> what-if"
az deployment group what-if \
  -g "$RG" \
  --template-file "$TPL" \
  "${PARAM_ARG[@]}"

if [[ "$APPLY" != "--apply" ]]; then
  echo
  echo "==> dry run only. Re-run with --apply to deploy."
  exit 0
fi

# ---------------------------------------------------- 5. deploy
STAMP=$(date +%Y%m%d-%H%M%S)
az deployment group create \
  -g "$RG" \
  -n "rebuild-$STAMP" \
  --template-file "$TPL" \
  "${PARAM_ARG[@]}"

echo
echo "==> deployed. MANUAL steps still outstanding:"
echo "    1. Seed Key Vault secrets   (names in inventory/$RG/keyvault/*NAMES-only*)"
echo "    2. Re-apply RBAC            (inventory/$RG/role-assignments.json — object"
echo "       IDs for MANAGED identities are new; users/groups carry over if same tenant)"
echo "    3. Re-apply diagnostic settings (inventory/$RG/diagnostic-settings/)"
echo "    4. Re-apply resource locks  (inventory/$RG/locks.json) — LAST, after data copy"
echo "    5. Migrate data             (azcopy / bacpac / service-specific)"
echo "    6. Re-point DNS + connection strings"
