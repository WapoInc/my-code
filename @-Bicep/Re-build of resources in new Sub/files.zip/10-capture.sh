#!/usr/bin/env bash
# 10-capture.sh — capture EVERYTHING needed to rebuild a resource group in a new subscription.
#
# Produces ./inventory/<rg>/ containing both the ARM/Bicep export AND the
# "invisible" config that export silently drops (RBAC, identities, diag settings,
# locks, policy, quota, providers).
#
# Usage: ./10-capture.sh <source-subscription-id> <resource-group> [more-rgs...]

set -euo pipefail

SRC_SUB="${1:?usage: 10-capture.sh <source-sub-id> <rg> [rg...]}"
shift
RGS=("$@")
[[ ${#RGS[@]} -eq 0 ]] && { echo "give me at least one resource group"; exit 1; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/inventory"

az account set --subscription "$SRC_SUB"
echo "==> source subscription: $(az account show --query name -o tsv)"

# ---------------------------------------------------------------- subscription
mkdir -p "$OUT/_subscription"
echo "--> subscription-level context"

# Registered providers: a NEW sub starts mostly unregistered. This list becomes
# your bootstrap step in the target.
az provider list \
  --query "[?registrationState=='Registered'].namespace | sort(@)" -o json \
  > "$OUT/_subscription/registered-providers.json"

# Custom RBAC roles are scoped to the OLD sub id and must be recreated.
az role definition list --custom-role-only true -o json \
  > "$OUT/_subscription/custom-role-definitions.json"

# Subscription-scope policy — may block your deploy in the target.
az policy assignment list -o json \
  > "$OUT/_subscription/policy-assignments.json"

# ------------------------------------------------------------- per-region quota
# Fresh subscriptions get default (low) quota. Check BEFORE you plan a cutover.
REGIONS=$(az resource list --query "[].location" -o tsv | sort -u)
for R in $REGIONS; do
  az vm list-usage -l "$R" \
    --query "[?currentValue > \`0\`].{name:localName,used:currentValue,limit:limit}" -o json \
    > "$OUT/_subscription/quota-compute-$R.json" 2>/dev/null || true
  az network list-usages -l "$R" \
    --query "[?currentValue > \`0\`].{name:name.localizedValue,used:currentValue,limit:limit}" -o json \
    > "$OUT/_subscription/quota-network-$R.json" 2>/dev/null || true
done

# ------------------------------------------------------------------ per-RG loop
for RG in "${RGS[@]}"; do
  echo "==> $RG"
  D="$OUT/$RG"; mkdir -p "$D"
  RG_SCOPE="/subscriptions/$SRC_SUB/resourceGroups/$RG"

  # -- 1. flat inventory (always works, even when export fails)
  az resource list -g "$RG" -o json > "$D/resources.json"
  az resource list -g "$RG" \
    --query "[].{name:name,type:type,location:location,sku:sku.name}" -o table \
    > "$D/resources.txt"

  COUNT=$(jq length "$D/resources.json")
  echo "    $COUNT resources"

  az group show -n "$RG" --query "{location:location,tags:tags}" -o json \
    > "$D/rg-metadata.json"

  # -- 2. ARM export (best-effort; hard 200-resource ceiling)
  if [[ "$COUNT" -gt 200 ]]; then
    echo "    !! >200 resources: az group export will refuse. Exporting per-resource."
    mkdir -p "$D/export-per-resource"
    jq -r '.[].id' "$D/resources.json" | while read -r ID; do
      SAFE=$(echo "$ID" | tr '/' '_')
      az group export -g "$RG" --resource-ids "$ID" \
        > "$D/export-per-resource/$SAFE.json" 2>/dev/null \
        || echo "    !! export failed: $ID"
    done
  else
    az group export -g "$RG" --include-parameter-default-value \
      > "$D/export.json" 2>"$D/export-warnings.txt" \
      || echo "    !! group export failed — see export-warnings.txt"
    # Warnings here list resource types that did NOT export. Read them.
    [[ -s "$D/export-warnings.txt" ]] && echo "    !! export warnings present"
    # Bicep is far easier to read/refactor than the JSON.
    [[ -s "$D/export.json" ]] && az bicep decompile --file "$D/export.json" --force 2>/dev/null || true
  fi

  # -- 3. deployment history: often CLEANER than a fresh export, because it is
  #       the template someone actually authored rather than a schema reflection.
  mkdir -p "$D/deployment-history"
  az deployment group list -g "$RG" --query "[].name" -o tsv 2>/dev/null | head -20 | \
  while read -r DEP; do
    az deployment group export -g "$RG" -n "$DEP" \
      > "$D/deployment-history/$DEP.json" 2>/dev/null || true
  done

  # -- 4. RBAC — never exported, always needed
  az role assignment list --scope "$RG_SCOPE" --include-inherited --all -o json \
    > "$D/role-assignments.json"

  # -- 5. managed identities — new sub means NEW principalIds; every grant that
  #       references these must be re-pointed after rebuild
  az identity list -g "$RG" -o json > "$D/user-assigned-identities.json"
  jq '[.[] | select(.identity != null)
       | {name, type, identity: .identity}]' "$D/resources.json" \
    > "$D/system-assigned-identities.json"

  # -- 6. locks
  az lock list -g "$RG" -o json > "$D/locks.json"

  # -- 7. RG-scope policy
  az policy assignment list -g "$RG" -o json > "$D/policy-assignments.json"

  # -- 8. Key Vault: names and access policies only. Values CANNOT be exported
  #       and must be re-seeded manually in the target.
  az keyvault list -g "$RG" --query "[].name" -o tsv | while read -r KV; do
    mkdir -p "$D/keyvault"
    az keyvault show -n "$KV" -o json > "$D/keyvault/$KV-config.json"
    az keyvault secret list --vault-name "$KV" \
      --query "[].{name:name,enabled:attributes.enabled,expires:attributes.expires}" -o json \
      > "$D/keyvault/$KV-secret-NAMES-only.json" 2>/dev/null || true
    az keyvault certificate list --vault-name "$KV" --query "[].name" -o json \
      > "$D/keyvault/$KV-cert-names.json" 2>/dev/null || true
  done

  # -- 9. diagnostic settings — dropped by export; losing these = losing all logs
  mkdir -p "$D/diagnostic-settings"
  jq -r '.[].id' "$D/resources.json" | while read -r ID; do
    DS=$(az monitor diagnostic-settings list --resource "$ID" -o json 2>/dev/null || echo '{"value":[]}')
    if [[ $(echo "$DS" | jq '.value | length') -gt 0 ]]; then
      echo "$DS" > "$D/diagnostic-settings/$(echo "$ID" | tr '/' '_').json"
    fi
  done

  # -- 10. alerting
  az monitor action-group list -g "$RG" -o json > "$D/action-groups.json" 2>/dev/null || true
done

echo
echo "==> done. Review these first:"
echo "    inventory/*/export-warnings.txt   <- what did NOT export"
echo "    inventory/_subscription/quota-*   <- will the target sub even fit this?"
echo "    inventory/*/keyvault/*NAMES-only* <- secrets you must re-seed by hand"
